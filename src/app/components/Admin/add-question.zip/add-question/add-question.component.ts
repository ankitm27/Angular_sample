import { Component, OnInit } from '@angular/core';
import * as $ from '../../../../../node_modules/jquery';
import { home, option } from '../home/home.model';
import { Router } from '@angular/router';
import axios from 'axios';
import { QuizStorageService } from 'src/app/service/quiz-storage.service';
import { SweetAlertService } from 'src/app/common/sweetalert2.service';

@Component({
  selector: 'app-add-question',
  templateUrl: './add-question.component.html',
  styleUrls: ['./add-question.component.css']
})
export class AddQuestionComponent implements OnInit {
  items = [];
  myvalue: number = 0;
  home = new home();
  option = new option()
  categoryList: any[] = [];
  dropdownSettings = {};
  tokenValue = this.storageService.get('token');
  public loading = false;
  numberOfQuestions = this.storageService.get('noofQuestions');
  countQuestion = this.storageService.get('countquestion');
  public singleoptions: any[] = [{
    option: '',

  }];
  // public multipleoptions: any[] = [{
  //   option: '',

  // }];
  dataArray = [];
  optionArray = [];
  quizid = this.storageService.get('quizId');

  questionModel: any = [{
    "question": "what is age",
    "question_type": "Question Type",
    "option_list": [""],
    "required": true
  }];

  optionList: any = [



  ]
  answerList: any = [

  ]
  constructor(private router: Router, private storageService: QuizStorageService,
    private sweetAlert: SweetAlertService) { }

  ngOnInit() {
    this.callAll();
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: false
    };
  }

  callAll() {
    // this.dataArray.push(this.home)
    this.addForm();
    //  this.OptionAdd();
    this.categoryList = this.optionList;
    // console.log(this.categoryList);
    const $button = document.querySelector('#sidebar-toggle');
    const $wrapper = document.querySelector('#wrapper');

    $button.addEventListener('click', (e) => {
      e.preventDefault();
      $wrapper.classList.toggle('toggled');

    });
    this.question_type();
    // console.log(this.formArraycheck, 'abcd');
  }


  question_type() {

    axios.get('http://env-9498608.cloudjiffy.net/api/admin/question_type', { headers: { "token": ` ${this.tokenValue}` } })
      .then((response) => {

        if (response.data.code == 200) {
          // console.log(response, 'response');
          this.optionList = response.data.list_question_type;

          // console.log(this.optionList, 'optionList');

        }

      })
  }

  addQuestion() {
    this.questionModel.push({
      "question": "",
      "question_type": "",
      "option_list": [],
      "required": false
    });

  }


  i = 0;
  neta: any = []
  j = 0;
  formArraycheck: any = [];
  checkValue: any = [];
  addForm() {
    // console.log(this.i);
    // console.log(this.j);

    this.home = new home();
    this.dataArray.push(this.home);

    this.formArraycheck.push({
      i: this.i++,
      option: []
    }

    )
    this.checkValue.push({
      j: this.j++,
      value: 1
    })
    // console.log(this.dataArray);
    // console.log(this.formArraycheck);
    // console.log(this.checkValue);



  }

  flag: any;
  checkopt(check_i: any) {
    let flag = check_i;
    // console.log(flag, 'flag');
    // console.log(check_i, 'check_i');

    // console.log(this.formArraycheck, 'formArraycheck');
    // console.log(this.checkValue, 'checkValue');
  }

  removeform(index: number) {
    let question: any = [];
    for (let ques = 0; ques < this.question.length; ques++) {
      if (ques == index) {

      } else {
        question.push(
          this.question[ques]
        )
      }
    }
    this.question = [];
    this.question = question;
    // console.log(this.question, 'this.question');
    this.dataArray.splice(index);
  }




  removeOption(index: any) {
    this.questionModel[0].option_list.splice(index, 1);
  }

  clickOption(index: string | number, value: any) {
    this.questionModel[index].question_type = value
  }

  checkvalue: any;

  onChange(deviceValue: number, _flag: any) {
    this.flag = _flag

    for (let i of this.checkValue) {
      if (i.j == this.flag) {

        i.value = deviceValue
      }
    }




  }

  // OptionAdd() {
  //   this.option = new option();

  //   this.optionArray.push(this.option);
  // }
  // OptionRemove(index: number) {
  //   this.optionArray.splice(index);
  // }
  save() {
    alert('Quiz has been saved');
    this.router.navigate(['admin/addQuiz']);
  }
  optionListAnswer: any = [];
  dropdownList = [];
  dropdownList1: any = []
  addmultiple(check: any) {
    console.log(check, 'check');
    console.log(this.formArraycheck, 'check');
    for (let ch of this.formArraycheck) {
      console.log(ch.i, 'check');

      if (ch.i == check) {
        ch.option.push({
          option: '',

        });

      }
      console.log(this.formArraycheck, 'multipleoptions');
     
    }

    this.local();

  }
  value:any;
 
  local() {
    // for (let opt of this.formArraycheck) {
    //   this.dropdownList1 = opt.option
    //   let asa = 0;
    //   console.log(this.dropdownList1)
    //   this.dropdownList = [];
    // }  
    let l =0;
      for (let opt of this.formArraycheck) {
        // this.dropdownList.push({
        //   'item_text':opt.option
        // });
      
        console.log('this opt', opt.option);
        // console.log('this', opt.option[l][l]);        
        // l = l+1
      }
      
    
   
  }
  addsingle() {
    this.singleoptions.push({
      option: '',

    });
  }
  removemultiple(_ch, i: number) {

    for (let j of this.formArraycheck) {
      if (j.i == _ch) {
        j.option.splice(i, 1);
      }
    }

  }
  removesingle(i: number) {
    this.singleoptions.splice(i, 1);
  }
  question: any = [];
  questionType: any = []



  onChnageAns(_value, _i) {
    this.answerList.push({
      i: _i,
      value: _value
    })
  }
  totalQuestion = this.numberOfQuestions - this.countQuestion
  saveQues() {



    let json = []

    let json1: any = '';
    for (let i of this.checkValue) {
      let option: any = [];
      for (let opt of this.formArraycheck) {
        if (i.j == opt.i) {
          if (i.value == 2) {
            for (let otp = 0; otp < opt.option.length; otp++) {
              option.push({
                'name': opt.option[otp][otp]
              });
            }
          } else {

          }
        }

      }
      console.log(option, 'check option');
      for (let ques = 0; ques < this.question.length; ques++) {
        if (i.j == ques) {
          if (i.value == 2) {
            for (let ans of this.answerList) {
              if (i.j == ans.i) {
                json1 = {
                  'question': this.question[ques],
                  'questionType': i.value,
                  'options': [option],
                  'correctOption': ans.value,
                  'quizid': this.quizid,
                }
                json.push(
                  json1
                );
                json1 = '';
              }
            }
          } else if (i.value == 1) {
            json1 = {
              'question': this.question[ques],
              'questionType': i.value,
              'options': [],
              'correctOption': '',
              'quizid': this.quizid,
            }
            json.push(
              json1
            );
            json1 = '';
          }
        }
      }

    }

    console.log(JSON.stringify(json), 'json');
    console.log('question value', this.question.length);
    console.log('numberOfQuestions length', this.numberOfQuestions);
    console.log(this.countQuestion, 'countQuestion');
    if (this.question.length < this.numberOfQuestions || this.question.length <= this.totalQuestion) {
      console.log('first condtion checked')


      console.log('countQuestion', this.countQuestion);
      console.log('numberOfQuestions', this.numberOfQuestions);
      console.log('QuestionLength', this.question.length);
      axios.post('http://env-9498608.cloudjiffy.net/api/admin/questions', json, { headers: { "token": ` ${this.tokenValue}` } })
        .then((res) => {
          if (res.data.code == 200) {
            // console.log(json, 'json');
            this.checkValue = [];
            this.question = [];
            this.formArraycheck = [];
            this.dataArray = [];
            this.i = 0;
            this.j = 0;
            this.sweetAlert.swalSuccess('Question added Successfully!!');
            this.storageService.set('quizId', this.quizid);
            this.router.navigate(['/admin/manageQuestion'])
          } else if (res.data.code != 200) {
            this.sweetAlert.swalError('Failed! Please try Again!!');
          }
          // console.log(res, 'response');


          this.loading = false;
        })


    }
    else {
      this.sweetAlert.swalError('Number of question is more than Quiz size');
      this.loading = false;

    }





    //this.callAll();
  }
  viewQuestion() {
    this.router.navigate(['/admin/manageQuestion']);
    this.storageService.set('quizId', this.quizid);
  }
}
